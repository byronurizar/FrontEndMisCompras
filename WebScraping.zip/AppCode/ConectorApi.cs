﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebScrapingMisCompras.Models;

namespace WebScrapingMisCompras.AppCode
{
    public class ConectorApi
    {
        public List<Producto> productosBd = new List<Producto>();
        public List<Catalogo> catalogosBd = new List<Catalogo>();
        public List<Categoria> categoriasBd = new List<Categoria>();
        public List<CatTipoInfoAdicional> tipoInfoAdicionalBd = new List<CatTipoInfoAdicional>();
        public List<ResultLog> logResult = new List<ResultLog>();
        public List<ProductoCruzado> productoCruzadoBd = new List<ProductoCruzado>();
        public List<DetalleProductoCruzado> detalleProdCruzadoBd = new List<DetalleProductoCruzado>();
        public List<InfoAdicionalProducto> InfoAdicionalProductoBd = new List<InfoAdicionalProducto>();
        public List<ImagenProducto> imagenesProductoBD = new List<ImagenProducto>();
        public List<ProductoCruzadoAux> productoCruzadoAux = new List<ProductoCruzadoAux>();
        string BaseUri = "http://api.misapps.tk/apiStore/v1/";
        //string BaseUri = "http://127.0.0.1:3500/apiStore/v1/";
        string token = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjMsImlhdCI6MTU5NTYwMzQxNX0.kHZP9lQa75dbniwzw6xjZYUNk1AqQ_7I-mo3A3mQJfo";
        public ConectorApi()
        {
            /*
            GetProductosBd();
            GeImagenesProductoBd();
            GetCatalogosBd();
            GetCategoriasBd();
            GetTipoInfoAdicional();
            GetTInfoAdicionalProducto();
            GetProductoCruzado();
            GetProductoCruzadoDetalle();
            */
        }
        public void GetProductosBd()
        {
            RespuestaApi rsp = new RespuestaApi();
            rsp = Get("productos");
            if (rsp.codigo == 0)
            {
                if (rsp.data != null)
                {
                    productosBd = JsonConvert.DeserializeObject<List<Producto>>(rsp.data.ToString());
                }
                else
                {
                    MessageBox.Show("Actualmente no existe ningún producto en la base de datos", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Ocurrió un errror al intentar obtener los productos de la api", "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void GetCatalogosBd()
        {
            RespuestaApi rsp = new RespuestaApi();
            rsp = Get("catalogos");
            if (rsp.codigo == 0)
            {
                if (rsp.data != null)
                {
                    catalogosBd = JsonConvert.DeserializeObject<List<Catalogo>>(rsp.data.ToString());
                }
                else
                {
                    MessageBox.Show("Actualmente no existe ningún catálogo en la base de datos", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Ocurrió un errror al intentar obtener los catálogos de la api", "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void GeImagenesProductoBd()
        {
            RespuestaApi rsp = new RespuestaApi();
            rsp = Get("imagenesproducto");
            if (rsp.codigo == 0)
            {
                if (rsp.data != null)
                {
                    imagenesProductoBD = JsonConvert.DeserializeObject<List<ImagenProducto>>(rsp.data.ToString());
                }
                else
                {
                    MessageBox.Show("Actualmente no existe ninguna imagen en base de datos", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Ocurrió un errror al intentar obtener las imagens de los productos de la api", "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void GetCategoriasBd()
        {
            RespuestaApi rsp = new RespuestaApi();
            rsp = Get("categorias");
            if (rsp.codigo == 0)
            {
                if (rsp.data != null)
                {
                    categoriasBd = JsonConvert.DeserializeObject<List<Categoria>>(rsp.data.ToString());
                }
                else
                {
                    MessageBox.Show("Actualmente no existe ninguna categoría en la base de datos", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Ocurrió un errror al intentar obtener las categorias de la api", "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void GetTipoInfoAdicional()
        {
            RespuestaApi rsp = new RespuestaApi();
            rsp = Get("tipoinfoadicional/producto");
            if (rsp.codigo == 0)
            {
                if (rsp.data != null)
                {
                    tipoInfoAdicionalBd = JsonConvert.DeserializeObject<List<CatTipoInfoAdicional>>(rsp.data.ToString());
                }
                else
                {
                    MessageBox.Show("Actualmente no existe ningun tipo de información en la base de datos", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Ocurrió un errror al intentar obtener los tipos de información adicional de la api", "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void GetTInfoAdicionalProducto()
        {
            RespuestaApi rsp = new RespuestaApi();
            rsp = Get("infoadicionalproductolistar");
            if (rsp.codigo == 0)
            {
                if (rsp.data != null)
                {
                    InfoAdicionalProductoBd = JsonConvert.DeserializeObject<List<InfoAdicionalProducto>>(rsp.data.ToString());
                }
                else
                {
                    MessageBox.Show("Actualmente no existe información adicional de productos en la base de datos", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Ocurrió un errror al intentar obtener la información adicional de productos de la api", "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void GetProductoCruzado()
        {
            RespuestaApi rsp = new RespuestaApi();
            rsp = Get("productocruzado");
            if (rsp.codigo == 0)
            {
                if (rsp.data != null)
                {
                    productoCruzadoBd = JsonConvert.DeserializeObject<List<ProductoCruzado>>(rsp.data.ToString());
                }
                else
                {
                    MessageBox.Show("Actualmente no existe ningun producto cruzado en la base de datos", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Ocurrió un errror al intentar obtener los productos cruzados de la api", "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void GetProductoCruzadoDetalle()
        {
            RespuestaApi rsp = new RespuestaApi();
            rsp = Get("productocruzado/detalle");
            if (rsp.codigo == 0)
            {
                if (rsp.data != null)
                {
                    detalleProdCruzadoBd = JsonConvert.DeserializeObject<List<DetalleProductoCruzado>>(rsp.data.ToString());
                }
                else
                {
                    MessageBox.Show("Actualmente no existen detalle de productos cruzados en la base de datos", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Ocurrió un errror al intentar obtener el detalle de productos cruzados de la api", "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void RegistrarProducto(ref Producto productoRef)
        {
            Producto producto = new Producto();
            producto = productoRef;
            RespuestaApi rsp = new RespuestaApi();
            bool existe = false;
            var existeProd = productosBd.Where(item => item.nombre.Trim().ToLower() == producto.nombre.Trim().ToLower());

            List<Producto> productosExistentes = new List<Producto>();
            productosExistentes = existeProd.ToList();
            if (productosExistentes.Count > 0)
            {
                productoRef = productosExistentes[0];
                existe = true;
            }
            if (!existe)
            {
                rsp = Post("productos/registro", producto);
                if (rsp.codigo == 0)
                {
                    productoRef = JsonConvert.DeserializeObject<Producto>(rsp.data.ToString());
                    productosBd.Add(productoRef);
                }
                else
                {
                    MessageBox.Show("Ocurrió un error al intentar registrar el Producto " + producto.nombre, "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public void RegistrarCatalogo(ref Catalogo catalogoRef)
        {
            Catalogo catalogo = new Catalogo();
            catalogo = catalogoRef;
            RespuestaApi rsp = new RespuestaApi();
            bool existe = false;
            var existeCatalogo = catalogosBd.Where(item => item.descripcion.Trim().ToLower() == catalogo.descripcion.Trim().ToLower() && item.idProveedor == catalogo.idProveedor);

            List<Catalogo> listaExistente = new List<Catalogo>();
            listaExistente = existeCatalogo.ToList();
            if (listaExistente.Count > 0)
            {
                catalogoRef = listaExistente[0];
                existe = true;
            }
            if (!existe)
            {
                rsp = Post("catalogos/registro", catalogo);
                if (rsp.codigo == 0)
                {
                    catalogoRef = JsonConvert.DeserializeObject<Catalogo>(rsp.data.ToString());
                    catalogosBd.Add(catalogoRef);
                }
                else
                {
                    MessageBox.Show("Ocurrió un error al intentar registrar el Catálogo " + catalogo.descripcion, "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public void RegistrarCategoria(ref Categoria categoriaRef)
        {
            Categoria categoria = new Categoria();
            categoria = categoriaRef;
            RespuestaApi rsp = new RespuestaApi();
            bool existe = false;
            var existeCategoria = categoriasBd.Where(item => item.descripcion.Trim().ToLower() == categoria.descripcion.Trim().ToLower());

            List<Categoria> listaExistente = new List<Categoria>();
            listaExistente = existeCategoria.ToList();
            if (listaExistente.Count > 0)
            {
                categoriaRef = listaExistente[0];
                categoriaRef.url = categoria.url;
                existe = true;
            }
            if (!existe)
            {
                rsp = Post("categorias/registro", categoria);
                if (rsp.codigo == 0)
                {
                    categoriaRef = JsonConvert.DeserializeObject<Categoria>(rsp.data.ToString());
                    categoriasBd.Add(categoriaRef);
                    categoriaRef.url = categoria.url;
                }
                else
                {
                    MessageBox.Show("Ocurrió un error al intentar registrar la categoría " + categoria.descripcion, "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public void RegistrarTipoInformacionAdicional(ref CatTipoInfoAdicional infoAdicionalRef)
        {
            CatTipoInfoAdicional tipoInfoAdicional = new CatTipoInfoAdicional();
            tipoInfoAdicional = infoAdicionalRef;
            RespuestaApi rsp = new RespuestaApi();
            bool existe = false;
            var existeInfoAdicional = tipoInfoAdicionalBd.Where(item => item.descripcion.Trim().ToLower() == tipoInfoAdicional.descripcion.Trim().ToLower());

            List<CatTipoInfoAdicional> listaExistente = new List<CatTipoInfoAdicional>();
            listaExistente = existeInfoAdicional.ToList();
            if (listaExistente.Count > 0)
            {
                infoAdicionalRef = listaExistente[0];
                existe = true;
            }
            if (!existe)
            {
                rsp = Post("tipoinfoadicional/producto", tipoInfoAdicional);
                if (rsp.codigo == 0)
                {
                    infoAdicionalRef = JsonConvert.DeserializeObject<CatTipoInfoAdicional>(rsp.data.ToString());
                    tipoInfoAdicionalBd.Add(infoAdicionalRef);
                }
                else
                {
                    MessageBox.Show("Ocurrió un error al intentar registrar el tipo de información adicional " + infoAdicionalRef.descripcion, "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public void RegistrarInfoAdicionalProducto(ref InfoAdicionalProducto infoAdicionalRef)
        {
            InfoAdicionalProducto infoAdicionalProd = new InfoAdicionalProducto();
            infoAdicionalProd = infoAdicionalRef;
            RespuestaApi rsp = new RespuestaApi();
            bool existe = false;
            var existeInfoAdicional = InfoAdicionalProductoBd.Where(item => item.idProducto==infoAdicionalProd.idProducto && item.idTipoInfoAdicional == infoAdicionalProd.idTipoInfoAdicional);

            List<InfoAdicionalProducto> listaExistente = new List<InfoAdicionalProducto>();
            listaExistente = existeInfoAdicional.ToList();
            if (listaExistente.Count > 0)
            {
                infoAdicionalRef = listaExistente[0];
                existe = true;
            }
            if (!existe)
            {
                rsp = Post("productos/infoadicional", infoAdicionalProd);
                if (rsp.codigo == 0)
                {
                    infoAdicionalRef = JsonConvert.DeserializeObject<InfoAdicionalProducto>(rsp.data.ToString());
                    InfoAdicionalProductoBd.Add(infoAdicionalRef);
                }
                else
                {
                    MessageBox.Show("Ocurrió un error al intentar registrar la información adicional del producto " + infoAdicionalProd.idProducto, "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public void RegistrarImagen(ref ImagenProducto imagenRef)
        {
            RespuestaApi rsp = new RespuestaApi();
            ImagenProducto imgAux = imagenRef;
            bool existe = false;
            var existeImagen = imagenesProductoBD.Where(item => item.idProducto == imgAux.idProducto).ToList();
            if (existeImagen.Count > 0)
            {
                existe = true;
            }
            if (!existe)
            {
                rsp = PostImagen("productos/imagenes/registro", imagenRef);
                if (rsp.codigo == 0)
                {
                    imagenRef = JsonConvert.DeserializeObject<ImagenProducto>(rsp.data.ToString());
                }
                else
                {
                    MessageBox.Show("Ocurrió un error al intentar registrar la imagen del producto " + imagenRef.idProducto, "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }
        public void RegistrarProductoCruzado(ref ProductoCruzado productoCruzadoRef)
        {
            ProductoCruzado productoCruzado = new ProductoCruzado();
            productoCruzado= productoCruzadoRef;
            RespuestaApi rsp = new RespuestaApi();
            bool existe = false;
            var existeInfoAdicional = productoCruzadoBd.Where(item => item.idProducto == productoCruzado.idProducto);

            List<ProductoCruzado> listaExistente = new List<ProductoCruzado>();
            listaExistente = existeInfoAdicional.ToList();
            if (listaExistente.Count > 0)
            {
                productoCruzadoRef = listaExistente[0];
                existe = true;
            }
            if (!existe)
            {
                rsp = Post("productoscruzados/registro", productoCruzado);
                if (rsp.codigo == 0)
                {
                    productoCruzadoRef = JsonConvert.DeserializeObject<ProductoCruzado>(rsp.data.ToString());
                    productoCruzadoBd.Add(productoCruzadoRef);
                }
                else
                {
                    MessageBox.Show("Ocurrió un error al intentar registrar el producto cruzado del producto " + productoCruzado.idProducto, "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public void RegistrarDetalleProductoCruzado(ref DetalleProductoCruzado detalleProdCruzadoRef)
        {
            DetalleProductoCruzado detalleproductoCruzado = new DetalleProductoCruzado();
            detalleproductoCruzado = detalleProdCruzadoRef;
            RespuestaApi rsp = new RespuestaApi();
            bool existe = false;
            var existeInfoAdicional = detalleProdCruzadoBd.Where(item => item.idProductoCruzado==detalleproductoCruzado.idProductoCruzado && item.idProducto == detalleproductoCruzado.idProducto);

            List<DetalleProductoCruzado> listaExistente = new List<DetalleProductoCruzado>();
            listaExistente = existeInfoAdicional.ToList();
            if (listaExistente.Count > 0)
            {
                detalleProdCruzadoRef = listaExistente[0];
                existe = true;
            }
            if (!existe)
            {
                rsp = Post("productoscruzados/detalle/registro", detalleproductoCruzado);
                if (rsp.codigo == 0)
                {
                    detalleProdCruzadoRef = JsonConvert.DeserializeObject<DetalleProductoCruzado>(rsp.data.ToString());
                    detalleProdCruzadoBd.Add(detalleProdCruzadoRef);
                }
                else
                {
                    MessageBox.Show("Ocurrió un error al intentar registrar el detalle de producto cruzado " + detalleproductoCruzado.idProductoCruzado, "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public RespuestaApi Get(string url)
        {
            RespuestaApi rs = new RespuestaApi();
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(BaseUri);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Authorization", token);
                HttpResponseMessage response = null;
                response = client.GetAsync(url).Result;
                try
                {
                    var respuesta = response.Content.ReadAsStringAsync();
                    string responseResult = respuesta.Result;
                    rs = (RespuestaApi)JsonConvert.DeserializeObject(responseResult, typeof(RespuestaApi));
                }
                catch (Exception ex)
                {
                    rs.codigo = (int)response.StatusCode;
                    rs.error = response.ReasonPhrase;
                    rs.data = ex;
                }
            }
            catch
            {
                throw new Exception("Ocurrió un error al realizar la petición");
            }

            //ResultLog log = new ResultLog();
            //log.request = url;
            //log.response = rs;
            //escribirLog(log);
            return rs;
        }
        public void escribirLog(ResultLog log)
        {
            string path2 = Application.StartupPath + "/logs";
            try
            {
                if (!(Directory.Exists(path2)))
                {
                    Directory.CreateDirectory(path2);
                }
            }
            catch (Exception ex)
            {
                
            }
            string nombreLog = DateTime.Now.ToString("ddMMyyyy")+".txt";
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(path2, nombreLog), true))
            {
                outputFile.WriteLine(JsonConvert.SerializeObject(log));
            }

        }
        public RespuestaApi Post(string url, object jsonData)
        {
            RespuestaApi rs = new RespuestaApi();
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(BaseUri);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Authorization", token);
                HttpResponseMessage response = null;
                response = client.PostAsJsonAsync(url, jsonData).Result;
                try
                {
                    var respuesta = response.Content.ReadAsStringAsync();
                    string responseResult = respuesta.Result;
                    rs = (RespuestaApi)JsonConvert.DeserializeObject(responseResult, typeof(RespuestaApi));
                }
                catch (Exception ex)
                {
                    rs.codigo = (int)response.StatusCode;
                    rs.error = response.ReasonPhrase;
                    rs.data = ex;
                }
            }
            catch
            {
                throw new Exception("Ocurrió un error al realizar la petición");
            }
            ResultLog log = new ResultLog();
            log.request = jsonData;
            log.response = rs;
            escribirLog(log);
            return rs;
        }
        public RespuestaApi PostImagen(string url, ImagenProducto jsonData)
        {
            RespuestaApi rs = new RespuestaApi();
            try
            {
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(BaseUri);
                client.DefaultRequestHeaders.Add("Authorization", token);

                HttpResponseMessage response = null;

                //if (!File.Exists(jsonData.pahtImagen))
                //{
                //    throw new FileNotFoundException($"File [{jsonData.pahtImagen}] not found.");
                //}
                MultipartFormDataContent form = new MultipartFormDataContent();

               // FileStream fs = File.OpenRead(jsonData.pahtImagen);
                var streamContent = new StreamContent(jsonData.imagen);
                streamContent.Headers.Add("Content-Disposition", "form-data; name=\"imagen\"; filename=\"" + Path.GetFileName(jsonData.pahtImagen) + "\"");
                streamContent.Headers.Add("Content-Type", "image/jpeg");
                form.Add(streamContent, "imagen", Path.GetFileName(jsonData.pahtImagen));

                var idProducto = new StringContent(jsonData.idProducto.ToString());
                idProducto.Headers.Add("Content-Disposition", "form-data; name=\"idProducto\"");
                form.Add(idProducto);

                var idEstado = new StringContent(jsonData.idEstado.ToString());
                idEstado.Headers.Add("Content-Disposition", "form-data; name=\"idEstado\"");
                form.Add(idEstado);

                var esImagenPrincipal = new StringContent(jsonData.esImagenPrincipal.ToString());
                esImagenPrincipal.Headers.Add("Content-Disposition", "form-data; name=\"esImagenPrincipal\"");
                form.Add(esImagenPrincipal);

                response = client.PostAsync(url, form).Result;

                var respuesta = response.Content.ReadAsStringAsync();
                string responseResult = respuesta.Result;
                rs = (RespuestaApi)JsonConvert.DeserializeObject(responseResult, typeof(RespuestaApi));
            }
            catch (Exception ex)
            {
                throw new Exception("Ocurrió un error al realizar la petición");
            }
            ResultLog log = new ResultLog();
            log.request = jsonData;
            log.response = rs;
            escribirLog(log);
            return rs;
        }
    }
}