﻿namespace WebScrapingMisCompras
{
    partial class FormularioPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAmway = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnOmnilife = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAmway
            // 
            this.btnAmway.Location = new System.Drawing.Point(1384, 12);
            this.btnAmway.Name = "btnAmway";
            this.btnAmway.Size = new System.Drawing.Size(599, 179);
            this.btnAmway.TabIndex = 0;
            this.btnAmway.Text = "Amway";
            this.btnAmway.UseVisualStyleBackColor = true;
            this.btnAmway.Click += new System.EventHandler(this.btnAmway_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(773, 26);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(212, 46);
            this.button1.TabIndex = 2;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnOmnilife
            // 
            this.btnOmnilife.Location = new System.Drawing.Point(1384, 217);
            this.btnOmnilife.Name = "btnOmnilife";
            this.btnOmnilife.Size = new System.Drawing.Size(599, 170);
            this.btnOmnilife.TabIndex = 3;
            this.btnOmnilife.Text = "Omnilife";
            this.btnOmnilife.UseVisualStyleBackColor = true;
            this.btnOmnilife.Click += new System.EventHandler(this.btnOmnilife_Click);
            // 
            // FormularioPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2020, 1258);
            this.Controls.Add(this.btnOmnilife);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnAmway);
            this.Name = "FormularioPrincipal";
            this.Text = "FormularioPrincipal";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAmway;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnOmnilife;
    }
}