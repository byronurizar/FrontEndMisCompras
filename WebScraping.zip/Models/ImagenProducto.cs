﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebScrapingMisCompras.Models
{
    public class ImagenProducto
    {
        public int id { get; set; }
        public int idProducto { get; set; }
        public int esImagenPrincipal { get; set; }
        public int idEstado { get; set; }
        public string pahtImagen { get; set; }
        public FileStream imagen { get; set; }
    }
}
