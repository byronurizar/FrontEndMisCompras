﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebScrapingMisCompras.Models
{
   public class ProductoAux
    {
        public string urlProducto { get; set; }
        public string urlImagen { get; set; }
    }
}
