﻿using Newtonsoft.Json;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebScrapingMisCompras.AppCode;
using WebScrapingMisCompras.Models;

namespace WebScrapingMisCompras
{
    public partial class FormularioPrincipal : Form
    {
        public ConectorApi conector = new ConectorApi();
        public FormularioPrincipal()
        {
            InitializeComponent();
        }

        private void btnAmway_Click(object sender, EventArgs e)
        {
            var driver = GetDriver();
            driver.Manage().Window.Maximize();
            RegistrarCategoriasAmway(driver);
        }
        public IWebDriver GetDriver()
        {
            var user_agent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36";
            FirefoxOptions options = new FirefoxOptions();
            options.AddArgument("--disable-gpu");
            options.AddArgument($"user_agent={user_agent}");
            options.AddArgument("--ignore-certificate-errors");
            IWebDriver driver = new FirefoxDriver(Directory.GetCurrentDirectory(), options);
            return driver;
        }
        public List<Catalogo> CatalogosAmway()
        {
            int idProveedor = 1;
            List<Catalogo> catalogos = new List<Catalogo>();
            Catalogo catalogo = new Catalogo();
            //catalogo.idProveedor = idProveedor;
            //catalogo.descripcion = "Nutrición";
            //catalogo.idEstado = 1;
            //catalogo.url = "http://www.amway.com.gt/Store/Catalogue.aspx?show=PrdsList&IC=0&C=CI&line=C&NavM=N";
            //catalogos.Add(catalogo);

            catalogo = new Catalogo();
            catalogo.idProveedor = idProveedor;
            catalogo.descripcion = "Belleza";
            catalogo.idEstado = 1;
            catalogo.url = "http://www.amway.com.gt/Store/Catalogue.aspx?show=PrdsList&IC=0&C=BA&line=B&NavM=N";
            catalogos.Add(catalogo);

            //catalogo.idProveedor = idProveedor;
            //catalogo.descripcion = "Cuidado Personal";
            //catalogo.idEstado = 1;
            //catalogo.url = "http://www.amway.com.gt/Store/Catalogue.aspx?show=PrdsList&IC=0&C=EA&line=E&NavM=N";
            //catalogos.Add(catalogo);

            //catalogo.idProveedor = idProveedor;
            //catalogo.descripcion = "Hogar";
            //catalogo.idEstado = 1;
            //catalogo.url = "http://www.amway.com.gt/Store/Catalogue.aspx?show=PrdsList&IC=0&C=GB&line=G&NavM=N";
            //catalogos.Add(catalogo);
            return catalogos;
        }
        public void DescargarImagen(string urlImagen, ref ImagenProducto imgProd)
        {
            string extension = ".png";
            string path1 = Application.StartupPath + "/Imagenes";
            string path2 = Application.StartupPath + "/Imagenes";
            try
            {
                if (!(Directory.Exists(path1)))
                {
                    Directory.CreateDirectory(path1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error al descargar la imagen " + ex.ToString(), "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            path1 += "/" + DateTime.Now.ToString("ddMMyyyymmssffffff") + extension;
            using (WebClient client = new WebClient())
            {
                client.DownloadFile(new Uri(urlImagen.Replace("medium", "large")), path1);
            }

            if (!File.Exists(path1))
            {
                MessageBox.Show("No fue posible descargar la imagen", "Información", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            FileStream fs = File.OpenRead(path1);

            if (fs.Length >= 25000)
            {
                imgProd.imagen = fs;
                imgProd.pahtImagen = path1;
            }
            else
            {
                path2 += "/" + DateTime.Now.ToString("ddMMyyyymmssffffff") + extension;
                using (WebClient client = new WebClient())
                {
                    client.DownloadFile(new Uri(urlImagen), path2);
                }
                FileStream fs2 = File.OpenRead(path2);
                imgProd.imagen = fs2;
                imgProd.pahtImagen = path2;
            }
        }
        public void RegistrarCategoriasAmway(IWebDriver driver)
        {
            List<Catalogo> catalogos = new List<Catalogo>();
            catalogos = CatalogosAmway();
            foreach (Catalogo catalogo in catalogos)
            {
                Catalogo catalogoRef = catalogo;
                conector.RegistrarCatalogo(ref catalogoRef);
                if (catalogoRef.id > 0)
                {
                    driver.Navigate().GoToUrl(catalogo.url);
                    var hrefCategorias = driver.FindElements(By.CssSelector(".menu_izq_opciones > a"));

                    List<Categoria> categorias = new List<Categoria>();
                    foreach (var itemCategoria in hrefCategorias)
                    {
                        Categoria categoria = new Categoria();
                        categoria.descripcion = itemCategoria.Text.Trim();
                        categoria.url = itemCategoria.GetAttribute("href");
                        categoria.idEstado = 1;
                        categorias.Add(categoria);
                    }


                    foreach (Categoria categoriaAux in categorias)
                    {
                        Categoria categoria = categoriaAux;
                        categoria.descripcion = categoria.descripcion.Replace(catalogoRef.descripcion, "").Trim();
                        conector.RegistrarCategoria(ref categoria);
                        if (categoria.id > 0)
                        {
                            driver.Navigate().GoToUrl(categoria.url);
                            var listaProductosHml = driver.FindElements(By.CssSelector(".allproducts_product_sec1 > div.allproducts_product_sec1_image> a"));
                            List<ProductoAux> urlProductos = new List<ProductoAux>();
                            foreach (var itemProducto in listaProductosHml)
                            {
                                ProductoAux auxProd = new ProductoAux();
                                auxProd.urlProducto = itemProducto.GetAttribute("href");
                                var img = itemProducto.FindElement(By.TagName("img"));
                                auxProd.urlImagen = img.GetAttribute("src");
                                urlProductos.Add(auxProd);
                            }
                            foreach (ProductoAux auxProd in urlProductos)
                            {
                                driver.Navigate().GoToUrl(auxProd.urlProducto);
                                ImagenProducto imgProducto = new ImagenProducto();
                                DescargarImagen(auxProd.urlImagen, ref imgProducto);

                                if (imgProducto.imagen.Length > 25000)
                                {
                                    Producto producto = new Producto();
                                    try
                                    {
                                        var itemHmlNombre = driver.FindElement(By.CssSelector(".ppage_contenido_tit"));
                                        producto.nombre = itemHmlNombre.Text.Trim();
                                    }
                                    catch { }

                                    try
                                    {
                                        var itemHmlDescripcionCorta = driver.FindElement(By.CssSelector(".ppage_contenido_sub_title"));
                                        producto.descripcionCorta = itemHmlDescripcionCorta.Text.Trim();
                                    }
                                    catch { }

                                    string descripcionProducto = string.Empty;
                                    try
                                    {
                                        var itemHmlDescripcion = driver.FindElement(By.CssSelector(".ppage_contenido_des > span"));
                                        descripcionProducto = itemHmlDescripcion.Text.Trim();
                                    }
                                    catch { }

                                    try
                                    {
                                        var itemHmlCapsulas = driver.FindElement(By.CssSelector(".ppage_contenido_sub_title2 > span"));
                                        descripcionProducto += " " + itemHmlCapsulas.Text;
                                    }
                                    catch { }

                                    producto.descripcion = descripcionProducto;

                                    try
                                    {
                                        var itemHmlPrecio = driver.FindElement(By.CssSelector(".valor > span"));
                                        decimal parsePrecio = Convert.ToDecimal(itemHmlPrecio.Text.Replace("Q", string.Empty));
                                        producto.precio = parsePrecio;
                                    }
                                    catch
                                    {
                                        producto.precio = 0;
                                    }
                                    producto.nopagina = 0;
                                    producto.idCatalogo = catalogoRef.id;
                                    producto.idCategoria = categoria.id;
                                    producto.oferta = 0;
                                    producto.idEstado = 1;

                                    string extrarCodigo = string.Empty;
                                    extrarCodigo = auxProd.urlProducto;
                                    extrarCodigo = extrarCodigo.Replace("&C", "|");
                                    extrarCodigo = extrarCodigo.Replace("C=", "|");
                                    string[] itemsCodigo = extrarCodigo.Split('|');
                                    string codigo = itemsCodigo[1];
                                    producto.codigo = codigo;
                                    if (producto.precio > 20)
                                    {
                                        conector.RegistrarProducto(ref producto);
                                    }
                                    if (producto.id > 0)
                                    {
                                        var listaInfoAdicionalProductosHml = driver.FindElements(By.CssSelector(".tabs.ui-tabs.ui-widget.ui-widget-content.ui-corner-all > ul > li > a"));
                                        int contadorTabs = 0;
                                        foreach (var itemTab in listaInfoAdicionalProductosHml)
                                        {
                                            IWebElement contenidoTab = itemTab;
                                            if (contadorTabs > 0)
                                            {
                                                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", contenidoTab);
                                            }

                                            string titulo = itemTab.Text;
                                            string descripcionContenidoTab = string.Empty;
                                            string idContenido = itemTab.GetAttribute("href").Split('#')[1];
                                            var descripInfoAdicionalHtml = driver.FindElement(By.Id(idContenido));
                                            descripcionContenidoTab = descripInfoAdicionalHtml.Text;

                                            CatTipoInfoAdicional tipoInfoAdicional = new CatTipoInfoAdicional();
                                            tipoInfoAdicional.idEstado = 1;
                                            tipoInfoAdicional.descripcion = titulo.Trim();
                                            conector.RegistrarTipoInformacionAdicional(ref tipoInfoAdicional);
                                            if (tipoInfoAdicional.id > 0)
                                            {
                                                InfoAdicionalProducto infoAdicional = new InfoAdicionalProducto();
                                                infoAdicional.idEstado = 1;
                                                infoAdicional.idProducto = producto.id;
                                                infoAdicional.valor = descripcionContenidoTab;
                                                infoAdicional.idTipoInfoAdicional = tipoInfoAdicional.id;
                                                conector.RegistrarInfoAdicionalProducto(ref infoAdicional);
                                            }
                                            contadorTabs++;
                                        }


                                        imgProducto.idProducto = producto.id;
                                        imgProducto.idEstado = 1;
                                        imgProducto.esImagenPrincipal = 1;

                                        conector.RegistrarImagen(ref imgProducto);

                                        var listaHtmlProductoCruzado = driver.FindElements(By.CssSelector(".top_sellers_product_sec1_image > a"));
                                        ProductoCruzadoAux auxProdCruzado = new ProductoCruzadoAux();
                                        List<string> itemProdCruzados = new List<string>();
                                        foreach (var item in listaHtmlProductoCruzado)
                                        {
                                            string urlCruzado = item.GetAttribute("href");
                                            string extrarCodigo2 = string.Empty;
                                            extrarCodigo2 = urlCruzado;
                                            extrarCodigo2 = extrarCodigo2.Replace("&C", "|");
                                            extrarCodigo2 = extrarCodigo2.Replace("C=", "|");
                                            string[] itemsCodigo2 = extrarCodigo2.Split('|');
                                            string codigo2 = itemsCodigo2[1];
                                            itemProdCruzados.Add(codigo2);
                                        }
                                        if (itemProdCruzados.Count > 0)
                                        {
                                            auxProdCruzado.idProducto = producto.id;
                                            auxProdCruzado.productos = itemProdCruzados;
                                            conector.productoCruzadoAux.Add(auxProdCruzado);
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
            }

            foreach (ProductoCruzadoAux item in conector.productoCruzadoAux)
            {
                ProductoCruzado prodCruzado = new ProductoCruzado();
                prodCruzado.idEstado = 1;
                prodCruzado.idProducto = item.idProducto;
                conector.RegistrarProductoCruzado(ref prodCruzado);

                if (prodCruzado.id > 0)
                {
                    foreach (string item2 in item.productos)
                    {


                        bool existe = false;
                        Producto prodAux = new Producto();
                        var existeProd = conector.productosBd.Where(produ => produ.codigo == item2);
                        List<Producto> productosExistentes = new List<Producto>();
                        productosExistentes = existeProd.ToList();
                        if (productosExistentes.Count > 0)
                        {
                            prodAux = productosExistentes[0];
                            existe = true;
                        }

                        if (existe)
                        {
                            DetalleProductoCruzado detalleProdCruzado = new DetalleProductoCruzado();
                            detalleProdCruzado.idEstado = 1;
                            detalleProdCruzado.idProductoCruzado = prodCruzado.id;
                            detalleProdCruzado.idProducto = prodAux.id;
                            conector.RegistrarDetalleProductoCruzado(ref detalleProdCruzado);
                        }

                    }
                }
            }
            //textBox1.Text = JsonConvert.SerializeObject(conector.logResult);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ImagenProducto img = new ImagenProducto();
            DescargarImagen("http://www.amway.com.gt/img_pict/260_Catalog/Products/medium/260_0001.jpg", ref img);
            img.idProducto = 12;
            img.idEstado = 1;
            img.esImagenPrincipal = 1;
            DescargarImagen("http://www.amway.com.gt/img_pict/260_Catalog/Products/medium/260_0001.jpg", ref img);
            conector.RegistrarImagen(ref img);

            DescargarImagen("http://www.amway.com.gt/img_pict/260_Catalog/Products/large/260_0001.jpg", ref img);
        }

        private void btnOmnilife_Click(object sender, EventArgs e)
        {
            var driver = GetDriver();
            driver.Manage().Window.Maximize();
            RegistrarCategoriaOmnilife(driver);
        }

        public List<Categoria> categoriasOmnilife()
        {
            List<Categoria> categorias = new List<Categoria>();
            Categoria categoria = new Categoria();
            categoria.descripcion = "Cajas";
            categoria.idEstado = 1;
            categoria.url = "https://portal.omnilife.com/productos/categoria/cajas";
            categorias.Add(categoria);

            categoria = new Categoria();
            categoria.descripcion = "Botellines 200 ml";
            categoria.idEstado = 1;
            categoria.url = "https://portal.omnilife.com/productos/categoria/botellines-200-ml";
            categorias.Add(categoria);


            categoria = new Categoria();
            categoria.descripcion = "Otros formatos";
            categoria.idEstado = 1;
            categoria.url = "https://portal.omnilife.com/productos/categoria/otros-formatos";
            categorias.Add(categoria);

            categoria = new Categoria();
            categoria.descripcion = "Promocionales";
            categoria.idEstado = 1;
            categoria.url = "https://portal.omnilife.com/productos/categoria/promocionales";
            categorias.Add(categoria);

            return categorias;
        }
        public void RegistrarCategoriaOmnilife(IWebDriver driver)
        {
            Catalogo catalogo = new Catalogo();
            catalogo.descripcion = "Nutrición";
            catalogo.idProveedor = 2;
            catalogo.idEstado = 1;
            conector.RegistrarCatalogo(ref catalogo);
            if (catalogo.id > 0)
            {
                driver.Navigate().GoToUrl("https://portal.omnilife.com/start");

                var ltaPaises = driver.FindElements(By.CssSelector(".countryFlagButton"));
                foreach (var item in ltaPaises)
                {
                    string idPais = item.GetAttribute("data-idcountry");
                    if (idPais == "10")
                    {
                        IWebElement contenidoTab = item;
                       ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", contenidoTab);
                        break;
                    }
                }
                Thread.Sleep(10000);
                List<Categoria> categorias = new List<Categoria>();
                categorias = categoriasOmnilife();

                
                foreach (Categoria itemCategoria in categorias)
                {
                    driver.Navigate().GoToUrl(itemCategoria.url);
                    Thread.Sleep(10000);
                    var ltaUrlProductos = driver.FindElements(By.CssSelector(".product__link"));
                    List<string> ulrProducto = new List<string>();
                    foreach (var item in ltaUrlProductos)
                    {
                        ulrProducto.Add(item.GetAttribute("href"));
                    }
                    escribirProductos(ulrProducto);
                }
            }
        }
        public void escribirProductos(List<string> lista)
        {
            string path2 = Application.StartupPath + "/omnilife";
            try
            {
                if (!(Directory.Exists(path2)))
                {
                    Directory.CreateDirectory(path2);
                }
            }
            catch (Exception ex)
            {

            }
            string nombreLog ="productosjson";
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(path2, nombreLog), true))
            {
                outputFile.WriteLine(JsonConvert.SerializeObject(lista));
            }

        }
    }
}

